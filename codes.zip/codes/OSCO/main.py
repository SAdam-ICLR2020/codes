from keras.models import Sequential
from keras.layers import Dense
from keras.utils import to_categorical
import numpy as np
from opt import SAdam, SC_Adagrad, SC_RMSprop, OGD, AdamNC, Amsgrad, Adam
import matplotlib.pyplot as plt
from keras import regularizers
from keras.datasets import cifar10, mnist, cifar100
from keras.callbacks import EarlyStopping
import pickle


value_lambda = 0.01
num_classes = 10
data =3

def find_optimal(x_train, y_train, x_test, y_test):
    print('find_optimal')
    if data == 1 or data ==2:
        lr =0.001
    else:
        lr =0.01
    model = Sequential()
    model.add(Dense(num_classes, input_dim=x_train.shape[1], activation='softmax',
                    kernel_regularizer=regularizers.l2(value_lambda),kernel_initializer='zeros',
                    bias_regularizer= regularizers.l2(value_lambda), bias_initializer='zeros',
                    ))

    model.compile(loss='categorical_crossentropy',
                  optimizer=Adam(lr),
                  metrics=['accuracy'])
    e = EarlyStopping(monitor='val_loss', patience=1, verbose=0, mode='auto')
    model.fit(x_train, y_train, epochs=200, batch_size=512,
              validation_data=(x_train, y_train), verbose=2, callbacks=[e])
    return model



def evaluate_optimal_model(model, x_train, y_train, iterations):
    print('evaluate_optimal')

    num_samples = x_train.shape[0]
    batch_size = num_samples // iterations
    loss = []
    idx = np.arange(0, num_samples, batch_size)
    for idx_start, idx_end in zip(idx[:-1], idx[1:]):
        h = model.evaluate(x_train[idx_start: idx_end], y_train[idx_start: idx_end], batch_size =batch_size)
        loss.append(h[0])
    return np.array(loss)


def evaluate_model(x_train, y_train, opt, iterations):


    model = Sequential()
    model.add(Dense(num_classes, input_dim=x_train.shape[1], activation='softmax',
                   kernel_regularizer=regularizers.l2(value_lambda),kernel_initializer='zeros',
                    bias_regularizer=regularizers.l2(value_lambda), bias_initializer='zeros'))

    model.compile(loss='categorical_crossentropy',
                  optimizer=opt,
                  metrics=['accuracy'], )


    num_samples = x_train.shape[0]
    batch_size = num_samples // iterations
    loss = []
    idx = np.arange(0, num_samples, batch_size)
    for idx_start, idx_end in zip(idx[:-1], idx[1:]):
        h = model.train_on_batch(x_train[idx_start: idx_end], y_train[idx_start: idx_end])
        loss.append(h[0])
    return np.array(loss)


def main():
    iterations = 1000
    opt_methods = [Adam, SAdam, SC_Adagrad, SC_RMSprop, OGD, AdamNC, Amsgrad]
    name_methods = ['Adam', 'SAdam', 'SC_Adagrad', 'SC_RMSprop', 'OGD', 'AdamNC', 'Amsgrad']



    if data == 1:
        (x_train, y_train), (x_test, y_test) = cifar10.load_data()
    elif data == 2:
        (x_train, y_train), (x_test, y_test) = cifar100.load_data(label_mode = 'coarse')
    elif data ==3:
        (x_train, y_train), (x_test, y_test) = mnist.load_data()
    else:
        return


    y_train = to_categorical(y_train, num_classes)
    y_test = to_categorical(y_test, num_classes)


    N_train = len(x_train)
    N_test = len(x_test)
    x_test = np.reshape(x_test, (N_test, -1))/255
    x_train = np.reshape(x_train, (N_train, -1))/255



    print("Data shape: {}".format(x_train.shape[1:]))


    optimal_model = find_optimal(x_train, y_train, x_test, y_test)
    optimal_loss = evaluate_optimal_model(optimal_model, x_train, y_train, iterations)

    regret_dict = {}
    loss_dict = {}
    for opt, name in zip(opt_methods, name_methods):
        best_sum_regret = 1e12
        best_sum_loss = 1e12
        best_regret = None
        best_loss = None
        for lr in [0.1,0.01,0.001,0.0001]:
            loss = evaluate_model(x_train, y_train, opt(lr=lr), iterations)
            regret = loss - optimal_loss
            if np.sum(loss) < best_sum_loss:
                print(lr, name)
                best_sum_loss = np.sum(loss)
                best_regret = regret
                best_loss = loss
        regret_dict[name] = best_regret
        loss_dict[name] = best_loss

    with open('regret.pkl', 'wb') as dump_file:
        pickle.dump(regret_dict, dump_file)

    with open('loss.pkl', 'wb') as dump_file:
        pickle.dump(loss_dict, dump_file)


if __name__ == '__main__':
    main()
